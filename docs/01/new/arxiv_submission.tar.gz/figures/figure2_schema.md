# Figure 2: DecisionDB Relational Schema

## Decision identity definition
Not applicable to this figure. This is a structural diagram showing table relationships, not an empirical result.

## Representation axes
Not applicable. This figure shows the database schema, not representation parameter variation.

## Equivalence rule
Not applicable.

## Stability criterion
Not applicable.

## Sampling method
Not applicable. This figure is a structural diagram.

## Non-claims disclaimer
This figure makes no performance claims, optimization claims, or learning claims. It shows the relational structure of the DecisionDB schema, including five tables and their foreign-key relationships.
